package dev.selodev.mahasiswa.Util;

public class ServerAPI {
    public static final String URL_DATA = "http://wongselodev.com/mahasiswa/view_data.php";
    public static final String URL_INSERT = "http://wongselodev.com/mahasiswa/create_data.php";
    public static final String URL_DELETE = "http://wongselodev.com/mahasiswa/delete_data.php";
    public static final String URL_UPDATE = "http://wongselodev.com/mahasiswa/update_data.php";
}
